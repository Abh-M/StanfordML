function [C, sigma] = dataset3Params(X, y, Xval, yval)
%DATASET3PARAMS returns your choice of C and sigma for Part 3 of the exercise
%where you select the optimal (C, sigma) learning parameters to use for SVM
%with RBF kernel
%   [C, sigma] = DATASET3PARAMS(X, y, Xval, yval) returns your choice of C and 
%   sigma. You should complete this function to return the optimal C and 
%   sigma based on a cross-validation set.
%

% You need to return the following variables correctly.
C = 1;
sigma = 0.3;
values = [0.01, 0.03, 0.1, 0.3, 1, 3, 10, 30];
totalValues = length(values);
errors = zeros(1,totalValues);
lowestError = 999999;

% ====================== YOUR CODE HERE ======================
% Instructions: Fill in this function to return the optimal C and sigma
%               learning parameters found using the cross validation set.
%               You can use svmPredict to predict the labels on the cross
%               validation set. For example, 
%                   predictions = svmPredict(model, Xval);
%               will return the predictions on the cross validation set.
%
%  Note: You can compute the prediction error using 
%        mean(double(predictions ~= yval))
%


for c = 1:totalValues 
  for s = 1:totalValues
    reg = values(c);
    sig = values(s);
    fprintf("\n Trying C = %i sigma = %i",reg,sig);
    model= svmTrain(X, y, reg, @(X,y) @gaussianKernel(X,y,sig), 1e-3, 20); 
%    fprintf("\npaused Visualize training samples");
%    visualizeBoundary(X, y, model);
%    pause;
%    fprintf("\npaused Visualize Cross validation samples");
%    visualizeBoundary(Xval, yval, model);
%    pause;    
    predictions = svmPredict(model, Xval);
    predictionError = mean(double(predictions ~= yval));
    if predictionError < lowestError
      lowestError = predictionError;
      C = reg;
      sigma = sig;
      fprintf("\npaused found new values error : %i",predictionError);
%      visualizeBoundary(X, y, model);
%      pause;
    endif
  endfor
endfor

%close all;

fprintf("\n Done...");





% =========================================================================

end
