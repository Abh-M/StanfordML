function [J, grad] = linearRegCostFunction(X, y, theta, lambda)
%LINEARREGCOSTFUNCTION Compute cost and gradient for regularized linear 
%regression with multiple variables
%   [J, grad] = LINEARREGCOSTFUNCTION(X, y, theta, lambda) computes the 
%   cost of using theta as the parameter for linear regression to fit the 
%   data points in X and y. Returns the cost in J and the gradient in grad

% Initialize some useful values
m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;
grad = zeros(size(theta));

% ====================== YOUR CODE HERE ======================
% Instructions: Compute the cost and gradient of regularized linear 
%               regression for a particular choice of theta.
%
%               You should set J to the cost and grad to the gradient.
%

fprintf("\n X %i,%i",size(X));
fprintf("\n y %i,%i",size(y));
fprintf("\n theta %i,%i",size(theta));
fprintf("\n\n");

% cost function

h = X * theta;
J = 1/(2*m);
J = J * sum((h-y).^2);
J = J + (lambda/(2*m)) * (sum(theta(2:end).^2))



% Gradient 
cost = h - y;
for j = 1:length(theta)
    grad(j,1) = grad(j,1) + sum(cost.*X(:,j));
endfor

grad = grad.*(1/m);

for j = 2:length(theta)
  grad(j,1) = grad(j,1) + (lambda/m) * theta(j,1);
endfor


% =========================================================================

%grad = grad(:);

end
