

function [J grad] = nnCostFunction(nn_params, ...
                                   input_layer_size, ...
                                   hidden_layer_size, ...
                                   num_labels, ...
                                   X, y, lambda)
%NNCOSTFUNCTION Implements the neural network cost function for a two layer
%neural network which performs classification
%   [J grad] = NNCOSTFUNCTON(nn_params, hidden_layer_size, num_labels, ...
%   X, y, lambda) computes the cost and gradient of the neural network. The
%   parameters for the neural network are "unrolled" into the vector
%   nn_params and need to be converted back into the weight matrices. 
% 
%   The returned parameter grad should be a "unrolled" vector of the
%   partial derivatives of the neural network.
%

% Reshape nn_params back into the parameters Theta1 and Theta2, the weight matrices
% for our 2 layer neural network
Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), ...
                 hidden_layer_size, (input_layer_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), ...
                 num_labels, (hidden_layer_size + 1));

% Setup some useful variables
m = size(X, 1);

% You need to return the following variables correctly 
J = 0;
Theta1_grad = zeros(size(Theta1));
Theta2_grad = zeros(size(Theta2));

fprintf("\n Size of samples %i %i",size(X));
fprintf("\n Size of th1 %i %i",size(Theta1));
fprintf("\n Size of th2 %i %i",size(Theta2));


% ====================== YOUR CODE HERE ======================
% Instructions: You should complete the code by working through the
%               following parts.
%
% Part 1: Feedforward the neural network and return the cost in the
%         variable J. After implementing Part 1, you can verify that your
%         cost function computation is correct by verifying the cost
%         computed in ex4.m
          fprintf("\nConverting Y to vector form %i,%i\n",size(y));
          Y = numberToVector(y,num_labels);
          fprintf("\nAfter converting Y to vector form %i,%i\n",size(Y));
          
          a1 = [ones(m,1), X];
          fprintf("\nSize of a_1 %i %i",size(a1));
          z2 = a1 * Theta1'  ;
          fprintf("\nSize of z_2 %i %i",size(z2));
          a2 = [ones(1,rows(z2))',sigmoid(z2)];
          fprintf("\nSize of a2 %i %i",size(a2));
          z3 = a2 * Theta2';
          fprintf("\nSize of z3 %i %i",size(z3));
          a3 = sigmoid(z3);
          fprintf("\nSize of a3 %i %i",size(a3));
          jmat = (-1 * Y ).*(log(a3)) - (1 - Y).*(log(1-a3));
          fprintf("\nSize of jmat %i %i",size(jmat));
          J = sum(sum(jmat));
          J = J/m;          
%          reg = sum(sum((Theta1(:,1:columns(Theta1)-1)).^2)) + sum(sum((Theta2(:,1:columns(Theta2)-1)).^2)); 
         reg = 0;
         for j = 1:rows(Theta1)
            for k = 2:columns(Theta1)
              reg = reg + Theta1(j,k)^2;
            endfor
          endfor
          
          for j = 1:rows(Theta2)
            for k = 2:columns(Theta2)
              reg = reg + Theta2(j,k)^2;
            endfor
          endfor         
          reg = reg * (lambda/(2*m));         
          J = J + reg;
          
          fprintf("\n Reg version : %f %f\n",J,reg);
          
%
% Part 2: Implement the backpropagation algorithm to compute the gradients
%         Theta1_grad and Theta2_grad. You should return the partial derivatives of
%         the cost function with respect to Theta1 and Theta2 in Theta1_grad and
%         Theta2_grad, respectively. After implementing Part 2, you can check
%         that your implementation is correct by running checkNNGradients
%
%         Note: The vector y passed into the function is a vector of labels
%               containing values from 1..K. You need to map this vector into a 
%               binary vector of 1's and 0's to be used with the neural network
%               cost function.
%
%         Hint: We recommend implementing backpropagation using a for-loop
%               over the training examples if you are implementing it for the 
%               first time.
          fprintf("\n Starting backprop");
          
          d3 = a3 - Y;
          fprintf("\nd3 : %i %i",size(d3));
          sigd = sigmoidGradient(z2)';
          fprintf("\nsigGrad %i, %i",size(sigd));
          d2 = Theta2'(2:end,:) * d3'.*sigd;
          fprintf("\nd2 : %i %i\n",size(d2));
          
          DL2 = a2'*d3; 
          DL1 = a1'*d2';
          
          fprintf("\nDL2 : %i %i",size(DL2));
          fprintf("\nDL1 : %i %i",size(DL1));

          Theta1_grad = DL1'.*(1/m) + (lambda/m)*Theta1;
          Theta2_grad = DL2'.*(1/m) + (lambda/m)*Theta2;
          
          fprintf("\nTheta1_grad : %i %i",size(Theta1_grad));
          fprintf("\nTheta2_grad : %i %i\n",size(Theta2_grad));

   
% Part 3: Implement regularization with the cost function and gradients.
%
%         Hint: You can implement this around the code for
%               backpropagation. That is, you can compute the gradients for
%               the regularization separately and then add them to Theta1_grad
%               and Theta2_grad from Part 2.
%



















% -------------------------------------------------------------

% =========================================================================

% Unroll gradients
grad = [Theta1_grad(:) ; Theta2_grad(:)];


end
